﻿using System;
using System.Collections.Generic;
using System.Text;

namespace s2industries.ZUGFeRD
{
    public enum ZUGFeRDVersion
    {
        Version1 = 100,
        Version20 = 200,
        Version21 = 210
    }
}
