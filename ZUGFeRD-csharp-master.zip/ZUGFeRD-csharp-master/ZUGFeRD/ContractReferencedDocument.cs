﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace s2industries.ZUGFeRD
{
    public class ContractReferencedDocument : BaseReferencedDocument
    {
    }
}
